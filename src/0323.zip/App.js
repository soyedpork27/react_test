import React from 'react';
import Inputtest from './Inputtest';
import Inputtest2 from './Inputtest2';
import Login from './Login';

function App(props) {
 return (
  <>
   <Inputtest />
   <hr />
   <Inputtest2 />
   <hr />
   <Login />
   <hr />

  </>
 );
}

export default App;