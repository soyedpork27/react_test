import React from 'react';

function Footer(props) {
  return (
    <>
     <footer>
        <address>Copyright&copy;2022 React실습 allrights reserved.</address>
      </footer> 
    </>)
}

export default Footer;