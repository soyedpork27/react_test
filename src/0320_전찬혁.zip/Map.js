import React from 'react';


function Map(props) {
  return (
    <>

      <h2>맵 페이지 입니다.</h2>

    </>
  );
}

export default Map;