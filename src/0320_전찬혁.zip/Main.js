import React from 'react';
// import App from './App';

import {Link} from 'react-router-dom';

function Main(props) {
  return (
    <>
      <main>
        메인콘텐츠 영역입니다.
      </main>
    </>
  );
}

export default Main;