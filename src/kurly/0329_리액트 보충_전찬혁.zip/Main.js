import React from 'react';

function Main(props) {
  return (
    <>
      <h2>메인화면</h2>
    </>
  );
}

export default Main;