import React from 'react';

function Footer(props) {
  return (
    <>
      <address>Copyright&copy;2023 kurly allright reserved</address>
    </>
  );
}

export default Footer;