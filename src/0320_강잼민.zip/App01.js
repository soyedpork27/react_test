//라우터 라이브러리 불러오기
import React from 'react';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import Header from './Header';
import Map from './Map';
import Main from './Main';
import CssChange from './CssChange';
import NotFound from './NotFound';
import Footer from './Footer';
import './ind.css';

function App01() {
  return (
    <>
      <BrowserRouter>
        <Header />
          <Routes>
            <Route path='/' element={<Main />} />
            <Route path='/map' element={<Map />} />
            <Route path='/CssChange' element={<CssChange />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        <Footer />
      </BrowserRouter>
    </>
  );
}

export default App01;