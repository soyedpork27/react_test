

function CssChange() {
  return (
    <>
    <main>
    <h2>리액트에서 css 서식 적용하는 방법</h2>
    <ol>
      <li>자바스크립트 표현식을 통한 서식적용</li>
      <li>변수로 서식 적용하기</li>
      <li>외부 스타일 서식 적용하기 - import</li>
      <li>className을 통해서 연결하기</li>
      <li>css module 방식으로 연결하기</li>
    </ol>

    <h3 style={{backgroundColor:'#ff0', color:'#f00'}}>1. inline style로 서식 적용하기</h3>

    <h3>2. 변수로 자바스크립트 객체 처리하여 css 서식 적용하기</h3>
    
    <h3 className='txt01'>3. 외부스타일을 작성하여 import로 서식 불러 오기</h3>

    <h3>4. className, tag, id명으로 서식 적용하기</h3>

    <h3>5. css module 방식으로 서식 적용하기</h3>
  
    <p>스타일 서식을 적용하다 보면 같은 서식이 중복 적용 될 수 있는데, module 방식을 사용하면 css 클래스가 중첩되는 것을 방지할 수 있다.</p>
    </main>
    </>

  );
}

export default CssChange;
