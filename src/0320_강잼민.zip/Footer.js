import React from 'react';

function Footer() {
  return (
    <>
      <footer>
        <address>
          Copyright &copy; 2023 React 실습 all rights reserved.
        </address>
      </footer>
    </>
  );
}

export default Footer;