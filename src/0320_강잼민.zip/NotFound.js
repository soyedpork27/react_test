import React from 'react';

function Notfound() {
  return (
    <>
      <h3>NotFound 404 error</h3>
      <p>페이지를 찾을 수 없습니다.</p>
    </>
  );
}

export default Notfound;