import React from 'react';

function Map() {
  return (
    <>
      <main className='map'>
        <h2>맵 페이지 입니다.</h2>
      </main>
    </>
  );
}

export default Map;