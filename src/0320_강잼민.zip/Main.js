import React from 'react';

function Main() {
  return (
    <>
      <main>
        <h2>
        메인컨텐츠 영역
        </h2>
      </main>
    </>
  );
}

export default Main;